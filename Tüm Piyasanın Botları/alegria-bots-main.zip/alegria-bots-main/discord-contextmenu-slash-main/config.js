module.exports = {
    token: "OTAwMDI1Njc0NDgyNDgzMjUw.YW7UOg.SCEj092wOoGnbuLaZ_ohbCggO9U",
    prefx: "!",
    owner: "340047062068494337",
    sunucuID: "893226714040254494",
    
    roles: {
        muted: "893227976035012680",
    }, 

    embed: {
        sunucuAdı: "༒ Alegria",
        embedRenk: "RANDOM",
        authorTag: "༒ Alegria",
    },

    staffs: {
        banStaff: "893227948151275590",
        muteStaff: "893227948390383698",
    },

    logs:{
        mutelog: "900026342257618944",
        jaillog: "900026342257618944",
    },
    
    emojis: {
        OnayE: "✅",
        IptalE: "❌",
    }
}
