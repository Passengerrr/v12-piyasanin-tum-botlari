#  Slash ve Context Komutları
- Aşağıdaki görsellerde görüldüğü şekilde sistemi burda paylaşıyorum.

## Önemli
Botunu kurmadan ve davet ederken şunlara dikkat etmelisin;
1: ![photo](https://media.discordapp.net/attachments/798849910203875388/877996253168959569/unknown.png?width=1920&height=1080)
2: ![photo](https://media.discordapp.net/attachments/798849910203875388/877996704484442142/unknown.png?width=1920&height=1080)
3: Botu sunucuya davet edin ve botu başlatın.


## [!] ÇOK ÖNEMLİ [!]
Botun Intent'lerini açmayı unutma.<br>
Botun OAuth2 ayarlarını yapmayı unutma.<br>
Node Sürümünüzün v16 olması gerektiğini unutma.<br>
        
Kullanım videosu;
<a href="https://cdn.discordapp.com/attachments/798849910203875388/877999855233040435/Tanitim.mp4">Video</a>


## İletişim & Yardım İçin
- Discord: [acerhizm#0521](https://discord.com/users/340047062068494337)
