# Discord-Buttons
* Discord Buton olayı takılın kafanıza göre
 
 * Yıldız Atmayı Unutmayın :*

# ÇALMAYIN MQ KOLAY BİŞİ ZATEN

# Kurulum
Ayarlar.jsondaki ıd leri girip !button yazarsanız çalışacaktır.
Discord Developer Portaldan İntentleri Açmayı Unutmayın [Developer Portal](https://discord.com/developers/applications)
![image](https://user-images.githubusercontent.com/85019155/120544847-8bd07e00-c3f6-11eb-975c-de660536d654.png)

# Sorun Çıkarsa ?

* Discord Üzerinden Ulaşabilirsiniz Herhangi Bi Sorun Olmaz 
* ID : 852626571507662919
* Nick : Xpeaw#0001

# Örnek ;
![image](https://user-images.githubusercontent.com/85019155/120449014-ce616e80-c394-11eb-8b81-685e1942f20e.png)

# Serendia
Serendia Squad Sunucunada Gelmeyi Unutmayın
* https://cdn.discordapp.com/attachments/814960684705513482/854475799335534592/standard.gif
* [Discord](https://discord.gg/tzR6UAQEdR)
