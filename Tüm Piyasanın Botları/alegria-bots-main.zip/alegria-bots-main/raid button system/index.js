const { Discord, MessageEmbed ,Client } = require('discord.js');
const client = new Client();
const { MessageButton } = require('discord-buttons')(client);
const moment = require('moment');
const cfg = require('./ayarlar.json');

client.on('ready', async => {
  client.user.setPresence({ activity: { name:"Alegria 💚 Acer"}, status: "online" });
  console.log(`[${moment().format('YYYY-MM-DD HH:mm:ss')}] BOT: ${client.user.username} ismi ile giriş yapıldı!`);
  let BotSesKanalı = client.channels.cache.get(cfg.bot.botSesKanal);
  if (BotSesKanalı) BotSesKanalı.join().catch(err => console.error("Bot Ses Kanalına Bağlanamadı!"));
})

client.on("message", (message) => {

// İhtimaller

if (message.content !== "!button" || message.author.id === cfg.bot.BotOwner || message.author.bot) return;


// BUTONLAR
//--------------------------------\\

// V/K
let Vk = new MessageButton()
  .setStyle('red') // Rengi ayarlayabilirsiniz.
  .setLabel('Etkinlik, Duyuru') // Adını Değiştirebilirsiniz.
  .setID('V/K'); // Elleme Bunu

// D/C
let Dc = new MessageButton()
  .setStyle('green') // Rengi ayarlayabilirsiniz.
  .setLabel('Çekiliş Katılımcısı') // Adını Değiştirebilirsiniz.
  .setID('D/C'); // Elleme Bunu

//--------------------------------\\
/*
let XpeawEmbed = new MessageEmbed()
.setAuthor("Xpeaw")
.setColor("RANDOM")
.setDescription(`
<a:bluediamond:812366599754350592> **Selam, Sunucumuzdaki "Eğlence" Rollerini Almak İçin Butonlara Tıklamanız Yeterlidir.**

**__ROLLER__**;

\`>\` <@&${cfg.roles.vkrole}>
\`>\` <@&${cfg.roles.dc}>
\`>\` <@&${cfg.roles.gartic}>
`)
.setFooter(`Xpeaw was here!`)
.setTimestamp()
message.channel.send({ buttons: 
  [
    Vk, 
    Dc, 
    Gartic
  ], 
  embed: XpeawEmbed 
});*/
message.channel.send(`
:tada: Rollere erişmek için butonlara tıklaman yeterli!

❯ <@&${cfg.roles.vkrole}>

❯ <@&${cfg.roles.dc}>
`, { 
  buttons: [ Vk, Dc]
});
});

client.on('clickButton', async (button) => {
  // V/K
    if (button.id === 'V/K') {
        if (button.clicker.member.roles.cache.get(cfg.roles.vkrole)) {
            await button.clicker.member.roles.remove(cfg.roles.vkrole)
            await button.think(true);
            await button.reply.edit("Etkinlik, Duyuru rolünü üzerinden aldım.")
        } else {
            await button.clicker.member.roles.add(cfg.roles.vkrole)
            await button.think(true);
            await button.reply.edit("Etkinlik, Duyuru rolünü üzerine ekledim.")
        }
    }

  // D/C
    if (button.id === 'D/C') {
        if (button.clicker.member.roles.cache.get(cfg.roles.dc)) {
            await button.clicker.member.roles.remove(cfg.roles.dc)
            await button.think(true);
            await button.reply.edit(`Çekiliş Katılımcısı rolünü üzerinden aldım.`)
        } else {
            await button.clicker.member.roles.add(cfg.roles.dc)
            await button.think(true);
            await button.reply.edit(`Çekiliş Katılımcısı rolünü üzerine ekledim.`)
        }

    }
  // GARTIC
    if (button.id === 'Gartic') {
        if (button.clicker.member.roles.cache.get(cfg.roles.gartic)) {
            await button.clicker.member.roles.remove(cfg.roles.gartic)
            await button.think(true);
            await button.reply.edit(`Gartic.io Rolü Üzerinizden Alındı!`)
        } else {
            await button.clicker.member.roles.add(cfg.roles.gartic)
            await button.think(true);
            await button.reply.edit("Gartic.io Rolü Üzerinize Verildi!")
        }
    }
});


client.login(cfg.bot.token);
