const config = { 
//------------Connections-----------//
    Client_Token: 'ODg4NTUyMzk1NzQxNzQ1MTUz.YUUW5w.4dymwnS5njNQr8me4a3ayyLSKug',
    MongoDB_ConnectURL: '',
    //------------BotSettings-----------//
    Prefix: '.',
    BotOwners: ["340047062068494337"],
    Custom_Status_Text: 'Alegria 🧡 Acer',
    Custom_Status_Type: 'PLAYING', // => PLAYING / WATCHING / LISTENING
    Custom_Status: 'online', // => dnd / idle / online / invisible
    VoiceChannelID: '893586083361742919'
};
  
module.exports = config;
