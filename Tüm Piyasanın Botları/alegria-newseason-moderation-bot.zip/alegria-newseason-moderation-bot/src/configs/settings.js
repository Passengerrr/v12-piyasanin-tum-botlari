/**
 * Client Settings
 * @param { Client } client 
 */

 module.exports = (client) => {

    //General Settings
    client.settings = {

        Prefix: ".",
        Token: "ODg4NTUxOTUzMjA5MDk4MjUw.YUUWfg.Pu006m3HLJO2XTCWpqgwDeb6ntE",
        Owners: ["340047062068494337","484022069734932490"],
        OtherBots: ["895341843229851699","888888686698180648","893801777642749952","893801809704017922","893801741781442621","900025674482483250","833408940364005376","833939068248915979","888552395741745153","833939300659494923","833939119364112394","834408423923777577","888553187475333140","833939225639911504"],
        VoiceChannel: "893586083361742919",
        Activity: "PLAYING",
        Status: "online",
        MongoURL: "",
        Footer: "Alegria 🤍 Acer",
        DisableCooldownsForAdmins: true,

    };

    //Activity Messages
    client.statusMessages = [

        "Alegria 🤍 Acer"

    ];

    //Emojis
    client.systemEmojis = [

        ///System
        { emojiName: 'developer', emojiUrl: 'https://cdn.discordapp.com/emojis/853642013332865035.gif?v=1' },
        { emojiName: 'loading', emojiUrl: 'https://cdn.discordapp.com/emojis/857935194203226118.gif?v=1' },
        { emojiName: 'arrow', emojiUrl: 'https://cdn.discordapp.com/emojis/821298641863442442.gif?v=1' },
        { emojiName: 'crown', emojiUrl: 'https://cdn.discordapp.com/emojis/876942324909871114.gif?v=1' },
        { emojiName: 'crown2', emojiUrl: 'https://cdn.discordapp.com/emojis/876929331572662323.gif?v=1' },
        { emojiName: 'mark', emojiUrl: 'https://cdn.discordapp.com/emojis/876153262796079115.gif?v=1' },
        { emojiName: 'mark2', emojiUrl: 'https://cdn.discordapp.com/emojis/853641429146140684.png?v=1' },
        { emojiName: 'cross', emojiUrl: 'https://cdn.discordapp.com/emojis/876153078863253514.gif?v=1' },
        { emojiName: 'cross2', emojiUrl: 'https://cdn.discordapp.com/emojis/853641452227264522.png?v=1' },
        { emojiName: 'success', emojiUrl: 'https://cdn.discordapp.com/emojis/899734171805700166.gif?v=1' },

        ///Status
        { emojiName: 'online', emojiUrl: 'https://cdn.discordapp.com/emojis/686601950275698692.png?v=1' },
        { emojiName: 'dnd', emojiUrl: 'https://cdn.discordapp.com/emojis/686601950355390545.png?v=1' },
        { emojiName: 'idle', emojiUrl: 'https://cdn.discordapp.com/emojis/686601950069915667.png?v=1' },
        { emojiName: 'offline', emojiUrl: 'https://cdn.discordapp.com/emojis/686601950686609420.png?v=1' },
        { emojiName: 'web', emojiUrl: 'https://cdn.discordapp.com/emojis/825429354707288065.png?v=1' },

        ///Penal
        { emojiName: 'banned', emojiUrl: 'https://cdn.discordapp.com/emojis/748618263071555645.gif?v=1' },
        { emojiName: 'jailed', emojiUrl: 'https://cdn.discordapp.com/emojis/878303820181024788.png?v=1' },
        { emojiName: 'chatMuted', emojiUrl: 'https://cdn.discordapp.com/emojis/878303318743609384.png?v=1' },
        { emojiName: 'warned', emojiUrl: 'https://cdn.discordapp.com/emojis/826369282942042112.png?v=1' },

        ///Voice
        { emojiName: 'joined', emojiUrl: 'https://cdn.discordapp.com/emojis/742688545977794560.gif?v=1' },   
        { emojiName: 'leaved', emojiUrl: 'https://cdn.discordapp.com/emojis/742688545168293968.gif?v=1' },
        { emojiName: 'unMuted', emojiUrl: 'https://cdn.discordapp.com/emojis/871710450633564271.png?v=1' },
        { emojiName: 'muted', emojiUrl: 'https://cdn.discordapp.com/emojis/871710451086524416.png?v=1' },
        { emojiName: 'unDeafen', emojiUrl: 'https://cdn.discordapp.com/emojis/871710450243502091.png?v=1' },
        { emojiName: 'deafen', emojiUrl: 'https://cdn.discordapp.com/emojis/871710450138619915.png?v=1' },
        { emojiName: 'camera', emojiUrl: 'https://cdn.discordapp.com/emojis/839043294717542400.png?v=1' }

    ];

    //Guild Settings     
    client.guildSettings = {

        ///General
        guildID: "893226714040254494",
        guildTags: ["༒"],
        guildDiscriminator: "0977                                                                                                                                                                                                                                                                                                                                                                                                                                        ",
        guildTeams: [],
        meetRole: "901731495775965244",
        meetChannel: "902140474964459520",
        nameTag: "",
        dmMessages: true,
        unAuthorizedMessages: true,

        ///Staffs
        staffRoles: ["893227948591710218"],
        transporterSpears: ["893227948616876112"],
        registerSpears: ["893227948591710218"],
        staffGiver: "893227890060173314",
        botYt: "893227890676752444",

        ///Penals
        penals: {

            ///Ban
            ban: {
                staffs: ["893227948151275590"],
                penalPoint: 40,
                penalLimit: 5,
                log: "893739706213367829",
                banGifs: ['https://media1.tenor.com/images/ed33599ac8db8867ee23bae29b20b0ec/tenor.gif?itemid=14760307', 'https://media.giphy.com/media/fe4dDMD2cAU5RfEaCU/giphy.gif', 'https://media1.tenor.com/images/4732faf454006e370fa9ec6e53dbf040/tenor.gif?itemid=14678194'],
                unbanGifs: ['https://data.whicdn.com/images/192611812/original.gif'],
            },

            ///Jail
            jail: {
                staffs: ["893227948541358082"],
                jailRoles: ["893227974982246470"],
                jailChannel: "",
                penalPoint: 30,
                penalLimit: 5,
                log: "893739904436146217",
            },

            ///Chat Mute
            chatMute: {
                staffs: ["893227948390383698"],
                cmuteRoles: ["893227976035012680"],
                penalPoint: 20,
                penalLimit: 5,
                log: "893739845904658452",
            },

            ///Voice Mute
            voiceMute: {
                staffs: ["893227948499435582"],
                vmuteRoles: ["893227976060207144"],
                penalPoint: 20,
                penalLimit: 5,
                log: "893739845904658452",
            },

            ///Warn
            warn: {
                staffs: ["893227948591710218"],
                warnRoles: [{
                    warnCount: 1,
                    warnRole: "893228426981429308", 
                }, {
                    warnCount: 2,
                    warnRole: "893228427002388602",
                }, {
                    warnCount: 3,
                    warnRole: "893228427056910387",
                }],
                penalPoint: 10,
                log: "893740007691546634",
            },

        },

        ///Registration
        registration: {
            unregisterName: "",
            unregisterRoles: [],
            unregisterChannel: "",
            quarantineRole: "893227974835449886",
            familyRole: "893228422334148728",
        },

        ///Forbidden Tag
        forbiddenTag: {
            forbidRoles: ["893227974474727494"],
            forbidChannel: "893589800446210068",
            forbidLog: "902144365768613928",
        },

        ///Logs
        logs: {
            pointLog: "893739268768411668",
            voiceLog: "893740103564918835",
            messageLog: "893740155381366825",
            securityLog: "893731703858794506",
            transportLog: "893740058744614942",
        },

    };

};