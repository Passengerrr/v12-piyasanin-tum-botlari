# 🔊 null User Token sistemi
######  Herkese selam
######  ben null Mustafa


# 😎 Açıklama
###### Her tokene kanal ID si girmelisin yoksa hata alırsın!!
###### Ekip priv pub sunucunuz varsa bu bot sizlerin ses aktifliğini sağlayacaktır 
###### Orospu çocuğu milletin hakkını yeme ananı sikerim diyorsanızda benden pek bi farkınız yok

# 🎮 Yeni nesil token sistemi

###### Her 2 saatte bir değişen oynuyor sistemi sayesinde sürekli vds e girip tokenlerin oyunlarını değiştirmenize gerek yok.
###### Ayarlar bariz belli aptal aptal konuşup canımı sıkma 




![unknown](https://user-images.githubusercontent.com/60463845/151648850-21f54ab9-e7fe-411d-871c-e48acd6788ab.png)
![a](https://user-images.githubusercontent.com/60463845/151648852-dad7ff5b-1a11-4626-bf45-68c2226d5153.png)
![Adsız](https://user-images.githubusercontent.com/60463845/151648833-61811f71-ac07-4557-a2f8-acd330d081e6.png)

 

<h2 align="center">Discord Hesaplarım <img src="https://raw.githubusercontent.com/iampavangandhi/iampavangandhi/master/gifs/Hi.gif" width="30px"> </h2>

[![Discord Presence](https://lanyard-profile-readme.vercel.app/api/311625016276025364?hideDiscrim=true)](https://discord.com/users/311625016276025364)
[![Discord Presence](https://lanyard-profile-readme.vercel.app/api/770307586477522964?hideDiscrim=true)](https://discord.com/users/770307586477522964)
