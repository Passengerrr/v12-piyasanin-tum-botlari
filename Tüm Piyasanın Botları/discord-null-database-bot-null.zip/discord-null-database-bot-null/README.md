# Yeni versiyon 0.0.3

# Web siteden discorda giriş yapınca rol alma falan filan diye götü kalkmış insanlar varmış falan yapamıyanlarla daşak geçiyorlarmış alın kullanın dostlarım öyle orospu evlatlarına böyle database botu :)

<h2 align="center">Discord<img src="https://raw.githubusercontent.com/iampavangandhi/iampavangandhi/master/gifs/Hi.gif" width="30px"> </h2>

[![Discord Presence](https://lanyard-profile-readme.vercel.app/api/770307586477522964?hideDiscrim=true)](https://discord.com/users/770307586477522964)
