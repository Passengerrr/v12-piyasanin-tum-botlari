const Discord = require('discord.js');
const Config = require('../../config.json')
const ayarlar = require('../../roller.json')
const kanallar = require('../../kanallar.json')
exports.run = async (client, message, args) => {
    if (!message.member.hasPermission("ADMINISTRATOR")) {
        message.react(`${client.emojis.cache.find(x => x.name === "carpi")}`)
    }
    let enAltYetkiliRolü = message.guild.roles.cache.get(ayarlar.registeryetki); //dauren

    let yetkililer = message.guild.members.cache.filter(uye => !uye.user.bot && uye.roles.highest.position >= enAltYetkiliRolü.position && uye.presence.status !== "offline" && !uye.voice.channel).array();
    if (yetkililer.length == 0) return message.reply('Aktif olup, seste olmayan yetkili bulunmuyor!');
    let mesaj = await message.channel.send(`Aktif olup seste olmayan **${yetkililer.length}** Yetkiliye ses çağrısı yapmak istiyor musunuz? (evet/hayır)`);
    var filter = m => m.author.id === message.author.id && m.author.id !== client.user.id && !m.author.bot;
    message.channel.awaitMessages(filter, { max: 1, timeout: 10000 }).then(collected => {
        let cevap = collected.first();
        if (cevap.content.toLowerCase().startsWith('hayır')) {
            message.react(`${client.emojis.cache.find(x => x.name === "onay")}`)
            return message.channel.send(` İşlem iptal edildi!`)//.then(m => m.delete({timeout: ayarlar.basarili}))
        }
        if (cevap.content.toLowerCase().startsWith('evet')) {
            yetkililer.forEach((yetkili, index) => {
                message.react(`${client.emojis.cache.find(x => x.name === "onay")}`)
                setTimeout(() => {
                    yetkili.send(`Yetkin var ancak seste değilsin. Eğer sese girmez isen yetki yükseltimin göz önünde bulundurulacaktır.. İşin varsa afk odalarda durabilirsin.`).then(x => mesaj.edit(new Discord.MessageEmbed().setDescription(`${yetkili} Yetkilisine özelden mesaj atıldı!`).setColor(message.member.displayHexColor))).catch(err => message.channel.send(`${yetkili}, Aktifsin fakat ses kanallarında değilsin!`).then(x => mesaj.edit(new Discord.MessageEmbed().setDescription(`${yetkili} Yetkin var ancak seste değilsin. Eğer sese girmez isen yetki yükseltimin göz önünde bulundurulacaktır. Ayrıca dm'ni aç mesaj atamıyorum.`).setColor(message.member.displayHexColor))));
                }, index * 1000);
            });
        };
    });
};

exports.conf = {
    enabled: true,
    guildOnly: true,
    aliases: ["yetkiliçağır", "yetkili-çağır", "yçağır","yetkilidm"],
    permLevel: 0
};

exports.help = {
    name: 'yetkili-çağır',
    description: 'Sayım yapar.',
    usage: 'yetkili-çağır',
    kategori: 'yetkili'
};