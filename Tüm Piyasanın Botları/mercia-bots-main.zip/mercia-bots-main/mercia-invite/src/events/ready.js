const client = global.client;

module.exports = async () => {
  client.guilds.cache.forEach(async (guild) => {
    const invites = await guild.fetchInvites();
    client.invites.set(guild.id, invites);
  });
  client.user.setActivity("Mercia ❤️ Acer");
  console.log(client.user.tag)
      let botVoiceChannel = client.channels.cache.get("885993632816058438");
  if (botVoiceChannel) botVoiceChannel.join().catch(err => console.error("Bot ses kanalına bağlanamadı!"));
};

module.exports.conf = {
  name: "ready",
};
