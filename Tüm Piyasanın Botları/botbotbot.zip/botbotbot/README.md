# discord-moderation-bot
Discord Ekip Sunucuları İçin Her Komutu Kapsayan Bir Ekip Botu

discordu bırakcağım için tüm altyapılarımı paylaşıyorum star atarsanız sevinirim

Selam arkadaşlar bu altyapıyı discord platformunda yeni bot yapmaya başladığım zaman yapmıştım epeyce eski fakat çoğu komutunu güncelledim ve hatalı komut yok 

(alıntı kodlar vardır)

Kurulum:
Öncelikle ```Config.json``` klasörüne giriyoruz ve boş yerleri dolduruyoruz.
```kanallar.json``` ve ```roller.json``` kısmındada aynılarını yapıyoruz.
LunaCyber.js klasörüne göz atmayı unutmayın bu kadardı şimdi modülleri yükleyip altyapıya start verebilirsiniz.

destek için https://discord.gg/serendia
