# Cross-Moderation-Bot
Cross v12 Mongoose Moderation
https://discord.gg/serendia
